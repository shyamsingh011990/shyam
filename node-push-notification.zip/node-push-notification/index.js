//https://thihara.github.io/Web-Push/
const express =require ('express');
const webpush =require ('web-push');
//const path =require ('path');
const bodyparser =require ('body-parser');
var mongo = require('mongodb');
//var mysql = require('mysql');

const app = express();
//keeping clients stuff
//app.use(express.static(path.join(__dirname,"client")));
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: true }));


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://127.0.0.1:27017/mydb";

/*app.use((req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');

});
*/
const publicVapidkey='BGLgGzhY80ac8fS4PkT5CEkIoRN_nlIrdqGOyDHDp4CUqEtzT5w-SBMlEhl9INqB1paUtfndHwjb_WDsXKXWYZ0';
const privateVapidKey='bpWcw6xUO2RXuRA-lGZHOsJsLcFEcMi4MzUGPATijfE';

webpush.setVapidDetails('mailto:example@yourdomain.org',
  publicVapidkey,
  privateVapidKey
);
//var endpoint="https://updates.push.services.mozilla.com/wpush/v2/gAAAAABbsdKS4_plZO_fHOlnXs0Rg9TlNdzE15MgmjdPDPAAh46ep93T9loRHdfX7xKn_T__PDhw_dNJ90X0QWSx5fXwEwOuMcz1Oov0-CnkX2Gd6ewFdYyBz2m3kKmyuZ63zrdH3py3B6XGrgqiS6W2P3Nk7uEiT3MlW3qscoOE0oDmwZSiS1c"


/*var con = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  password: "root",
  database: "test"
});
*/

//var dbo = db.db("mydb");





//subscribe route
app.post('/subscribe',(req,res)=>{
	 res.header('Access-Control-Allow-Origin', '*');
	console.log('push receiving...');
//first get push sucription object from client
      let endpoint = req.body['notificationEndPoint'];
     let publicKey = req.body['publicKey'];
     let auth = req.body['auth'];
 //const subscription=req.body;
console.log(req.body);
console.log("The Public key is="+publicKey);
console.log("The authentication is="+auth);
console.log("the endpoint url is="+endpoint);



//var dbo


MongoClient.connect(url, function(err, db) {
  if (err) throw err;
   var dbo = db.db("mydb");
  dbo.createCollection("customers", function(err, res) {
    if (err) throw err;
    console.log("Collection created!");

var myobj = { endpointURL: endpoint, EncriptionKey: publicKey,authHeader:auth};
  dbo.collection("customers").insertOne(myobj, function(err, res) {
    if (err) throw err;
    console.log("1 document inserted");
  
  });



    db.close();
  });


});



res.status(201).json({});
//create payload ,we can attch qr here ,but sending title receved from cleint
const payload=JSON.stringify({title:'Payment Success for syf'})
//pass object to send notifcation function

let pushSubscription = {
         endpoint: endpoint,
         keys: {
             p256dh: publicKey,
             auth: auth
         }
     };


  


 
//webpush.sendNotification(pushSubscription,payload).catch(err=>console.error(err));
webpush.sendNotification(pushSubscription,payload).catch(err=>console.error(err));

});
const port =5000;
app.listen(port,()=>console.log('server started on port' +port))