//https://thihara.github.io/Web-Push/
const express =require ('express');
const webpush =require ('web-push');
const path =require ('path');
var bodyParser=require ('body-parser');
var mongo = require('mongodb');
var sleep = require('system-sleep');

const app = express();

//keeping clients stuff
//app.use(express.static(path.join(__dirname,"client")));
app.use(bodyParser.json());
//app.use(require('connect').bodyParser());
app.use(bodyParser.urlencoded({ extended: true }));
//app.use(bodyparser.urlencoded({ extended: false }));


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://127.0.0.1:27017/mydb";


const publicVapidkey='BGLgGzhY80ac8fS4PkT5CEkIoRN_nlIrdqGOyDHDp4CUqEtzT5w-SBMlEhl9INqB1paUtfndHwjb_WDsXKXWYZ0';
const privateVapidKey='bpWcw6xUO2RXuRA-lGZHOsJsLcFEcMi4MzUGPATijfE';

webpush.setVapidDetails('mailto:example@yourdomain.org',
  publicVapidkey,
  privateVapidKey
);






//subscribe route
app.post('/subscribe/hello',(req,res)=>{
	 res.header('Access-Control-Allow-Origin', '*');
   var obj = {};
 /* 
   res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
        res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
        res.setHeader('Access-Control-Allow-Credentials', true);*/
	console.log('push receiving...');
  //console.log('body: ' + JSON.stringify(req.body));
  //console.log(req.body.endpoint);

//first get push sucription object from client
      let endpoint = req.body.endpoint;
     let publicKey = req.body.publicKey;
     let auth = req.body.auth;
        
        
 //const subscription=req.body;
 //console.log(req.body);
// console.log(JSON.stringify(req.body));
console.log("req.body.notificationEndPoint="+endpoint);
console.log("req.body.publicKey="+publicKey);
console.log("req.body.auth="+auth);



 res.status(201).json({});
      //create payload ,we can attch qr here ,but sending title receved from cleint
      const payload=JSON.stringify({title:'Payment Successfully,please click on below link to get previous QR image'})


MongoClient.connect(url, function(err, db) {
  if (err) throw err;
   var dbo = db.db("mydb");
  dbo.createCollection("customers", function(err, res) {
    if (err) throw err;
    console.log("Collection created!");

var myobj = { endpointURL: endpoint, EncriptionKey: publicKey,authHeader:auth};
  dbo.collection("customers").insertOne(myobj, function(err, res) {
    if (err) throw err;
    console.log("1 document inserted");
  
  });

//written Mounisha
sleep(10*1000);

dbo.collection("customers").find({}).toArray(function(err, result) {
    if (err) throw err;
    //console.log(result);
    for (var i = 0; i < result.length; i++) {
      /*console.log(result[i].endpointURL);
      console.log("================");*/
     
    //pass object to send notifcation function

    let pushSubscription = {
         endpoint: result[i].endpointURL,
         keys: {
             p256dh: result[i].EncriptionKey,
             auth: result[i].authHeader
         }
     };

//webpush.sendNotification(pushSubscription,payload).catch(err=>console.error(err));
webpush.sendNotification(pushSubscription,payload).catch(err=>console.error(err));
    }
    db.close();
  });

    dbo.collection("customers").deleteMany({}, function(err, obj) {
    if (err) throw err;
    console.log("All entries deleted");
    db.close();
  });
//commit by mounisha

   db.close();
  });



});



/*res.status(201).json({});
//create payload ,we can attch qr here ,but sending title receved from cleint
const payload=JSON.stringify({title:'Payment Success for syf'})
//pass object to send notifcation function

let pushSubscription = {
         endpoint: endpoint,
         keys: {
             p256dh: publicKey,
             auth: auth
         }
     };

//webpush.sendNotification(pushSubscription,payload).catch(err=>console.error(err));
webpush.sendNotification(pushSubscription,payload).catch(err=>console.error(err));*/

});
const port =5000;
app.listen(port,()=>console.log('server started on port' +port))