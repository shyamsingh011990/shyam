const express =require ('express');
const webpush =require ('web-push');
const path =require ('path');
const bodyparser =require ('body-parser');

const app= express();
//keeping clients stuff
app.use(express.static(path.join(__dirname,"client")));
app.use(bodyparser.json())

const publicVapidkey='BGLgGzhY80ac8fS4PkT5CEkIoRN_nlIrdqGOyDHDp4CUqEtzT5w-SBMlEhl9INqB1paUtfndHwjb_WDsXKXWYZ0';
const privateVapidKey='bpWcw6xUO2RXuRA-lGZHOsJsLcFEcMi4MzUGPATijfE';

webpush.setVapidDetails('mailto:example@yourdomain.org',
  publicVapidkey,
  privateVapidKey
);

//subscribe route
app.post('/subscribe',(req,res)=>{
//first get push sucription object from client
const sucription=req.body;
//send 201-resorce creted 
res.status(201).json({});
//create payload ,we can attch qr here ,but sending title receved from cleint
const payload=JSON.stringify({title:'test payload'})
//pass object to send notifcation function
webpush.sendNotification(sucription,payload).catch(err=>console.error(err));

});
const port =5000;
app.listen(port,()=>console.log('server started on port ${port}'))