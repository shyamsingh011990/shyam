//handle push event
console.log('serviceworker loded')
self.addEventListener('push',e=>{
const data=e.data.json();
console.log('push received')

//publish to browser
self.registration.showNotification(data.title, {

	body:'notified by shyam'
	//icon:
});


});