const publicVapidkey='BGLgGzhY80ac8fS4PkT5CEkIoRN_nlIrdqGOyDHDp4CUqEtzT5w-SBMlEhl9INqB1paUtfndHwjb_WDsXKXWYZ0';



//check if sw support in current browser
if('serviceWorker' in navigator)
{
	send().catch(err=>console.log(err))
}

//now send()register serviceworker ,register push using browsers push api,send push(send notification)
async function send()
{
	console.log('Registering sw..');
	const register= await navigator.serviceWorker.register('/worker1.js',{scope:'/'}) ;
	console.log(' sw Registered..');
//Register push
console.log('Registering push..');
const subcription=await register.pushManager.subscribe({
userVisibleOnly: true,
applicationServerKey: urlBase64ToUint8Array(publicVapidkey)
	});
console.log('Push Registered..');
//console.log(subcription.endpoint);
//sending push..
            var endpoint = subcription.endpoint;
            var key = subcription.getKey('p256dh');
            var auth = subcription.getKey('auth');
            console.log("type of endpoint= "+typeof(endpoint)+" and type of key ="+typeof(key)+" and type of auth="+typeof(auth));
             
           var encodedKey = btoa(String.fromCharCode.apply(null, new Uint8Array(key)));
            var encodedAuth = btoa(String.fromCharCode.apply(null, new Uint8Array(auth)));
           /* console.log("value of enspoint= "+endpoint);
            console.log("value of key= "+encodedKey);
              console.log("value of auth= "+encodedKey);*/
sendSubscriptionToServer(endpoint, key, auth);
console.log('sending push..');

}


 



 function sendSubscriptionToServer(endpoint1, key, auth) {
    var encodedKey1 = btoa(String.fromCharCode.apply(null, new Uint8Array(key)));
    var encodedAuth1 = btoa(String.fromCharCode.apply(null, new Uint8Array(auth)));
    console.log("--------------------------------------- ");
      /*console.log("value of enspoint= "+endpoint1);
            console.log("value of key1= "+encodedKey1);
              console.log("value of auth1= "+encodedKey1);*/
/*let info = [];
info['notificationEndPoint'] = endpoint1;
info['publicKey'] = encodedKey1;
info['auth'] = encodedKey1;
    console.log("value of1 enspoint= "+info['notificationEndPoint']);
            console.log("value of 11 key1= "+info['publicKey']);
              console.log("value of  11 auth1= "+info['auth']);*/


              var data = {};
          data.endpoint = endpoint1;
          data.publicKey = encodedKey1;
          data.auth = encodedAuth1;

    // setTimeout(function(){
     $.ajax({
          url: 'http://localhost:5000/subscribe/hello',
            type: 'POST',
       
                //data: JSON.stringify(data),
                data:data,
       // data: {info:info},
        //data: {info1:'info1'},
        dataType: 'json',
        success: function (results) {
            console.log('Subscribed successfully! ' + JSON.stringify(results));
        },
         error: function(XMLHttpRequest, textStatus, errorThrown) {
              console.log(XMLHttpRequest);
        }
        
    });
   //},5000)
}

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/\-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

