//handle push event
console.log('serviceworker loded')
self.addEventListener('push',e=>{
const data=e.data.json();
console.log('push received')

//publish to browser
self.registration.showNotification(data.title, {

	body:'notified by shyam'
	//vibrate: [100, 50, 100],
	
	//openURL : 'https://facebook.com/'
	//icon:
   clients.openWindow(https://facebook.com/)

	//body: "Did you make a $1,000,000 purchase at Dr. Evil...",
  //icon: "images/ccard.png",
  vibrate: [200, 100, 200, 100, 200, 100, 400],
  /*tag: "request",
  actions: [
    { action: "yes", "title": "Yes", "icon": "images/yes.png" },
    { action: "no", "title": "No", "icon": "images/no.png" }
  ]
*/

});


});



/*self.addEventListener('push', function(event) {
  console.log('[Service Worker] Push Received.');
  console.log(`[Service Worker] Push had this data: "${event.data.text()}"`);
		//const data=e.data.json();

  const title = 'Push Codelab';
  const options = {
    body: 'Yay it works.',
    icon: 'images/icon.png',
    badge: 'images/badge.png'

  };

  event.waitUntil(self.registration.showNotification(title, options));
});*/