//handle push event
console.log('serviceworker loded')
self.addEventListener('push',e=>{
const data=e.data.json();
console.log('Got push', data);
console.log('push received')
data.title='SYF Payment';

//publish to browser
self.registration.showNotification(data.title, {
		title : 'SYF Payment',
	body: 'Payment is done',
    icon: 'http://mongoosejs.com/docs/images/mongoose5_62x30_transparent.png'
});


});



/*self.addEventListener('push', function(event) {
    if (!(self.Notification && self.Notification.permission === 'granted')) {
        return;
    }

    var data = {};
    if (event.data) {
        data = event.data.json();
    }
    var title = data.title;
    var message = data.message;
    var icon = "img/FM_logo_2013.png";

    self.clickTarget = data.clickTarget;

    event.waitUntil(self.registration.showNotification(title, {
        body: message,
        tag: 'push-demo',
        icon: icon,
        badge: icon
    }));
});


self.addEventListener('notificationclick', function(event) {
    console.log('[Service Worker] Notification click Received.');

    event.notification.close();

    if(clients.openWindow){
        event.waitUntil(clients.openWindow(self.clickTarget));
    }
});


Notification.requestPermission().then(function (status) {
    if (status === 'denied') {
        console.log('[Notification.requestPermission] The user has blocked notifications.');
        disableAndSetBtnMessage('Notification permission denied');
    } else if (status === 'granted') {
        console.log('[Notification.requestPermission] Initializing service worker.');
        initialiseServiceWorker();
    }
});*/