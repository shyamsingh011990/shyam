<?php

if(isset($_POST['token'])){
	$val = 'Sucess Token ID:'.$_POST['token'];
	echo json_encode($val);
}


