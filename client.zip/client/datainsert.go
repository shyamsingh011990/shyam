package main

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	  "net/http"
    "log"
    "github.com/gorilla/mux"
    //"encoding/json"
    "bytes"
)

var db *sql.DB
var stmt *sql.DB





func setupResponse(w *http.ResponseWriter, req *http.Request) {
	(*w).Header().Set("Access-Control-Allow-Origin", "*")
    (*w).Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE")
    (*w).Header().Set("Access-Control-Allow-Headers", "Accept, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization")
    (*w).Header().Set("Content-Type", "application/json")
}

func handler(w http.ResponseWriter, r *http.Request){
	setupResponse(&w, r)
	if (*r).Method == "OPTIONS" {
		return
	}
	if r.Method == "POST" {
 		//ajax_post_data := r.Body(Token)
 		//fmt.Println("Receive ajax post data string ", ajax_post_data)
 		buf := new(bytes.Buffer)
    buf.ReadBody(r.Body)
    newStr := buf.String()

    fmt.Printf(newStr)
 		w.Write([]byte("Sucess"))
 	}
	
	
}







func main() {


	

	//db, err := sql.Open("mysql", "user:password@/database")
	db, err := sql.Open("mysql", "root:root@tcp(127.0.0.1:3306)/test")
	if err != nil {
		panic(err.Error())  // Just for example purpose. You should use proper error handling instead of panic
	}
	defer db.Close()

	
r := mux.NewRouter()
	//r.HandleFunc("/", handler)
	r.HandleFunc("/insert", handler).Methods("POST","OPTIONS")

log.Fatal(http.ListenAndServe("localhost:8000", r))
}
