// Import and configure the Firebase SDK
// These scripts are made available when the app is served or deployed on Firebase Hosting
// If you do not serve/host your project using Firebase Hosting see https://firebase.google.com/docs/web/setup
importScripts('https://www.gstatic.com/firebasejs/5.4.1/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/5.4.1/firebase-messaging.js');

var config = {
    apiKey: "AIzaSyDSbWYLvRn1SjDGyieNJgWJcFaLdkSAmvo",
    authDomain: "mani-83d3a.firebaseapp.com",
    databaseURL: "https://mani-83d3a.firebaseio.com",
    projectId: "mani-83d3a",
    storageBucket: "mani-83d3a.appspot.com",
    messagingSenderId: "731257708840",
  };
  firebase.initializeApp(config);


var messaging = firebase.messaging();


messaging.setBackgroundMessageHandler(function(payload) {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  // Customize notification here
  var notificationTitle = "Your Payment was sucsess";
  var notificationOptions = {
    body :"goodbye",
//image :
icon:'https://www.pexels.com/photo/white-and-pink-floral-freestanding-letter-decor-949586/'
  };

  console.log(notificationOptions)
  return self.registration.showNotification(notificationTitle,
    notificationOptions);
});

console.log(messaging.bgMessageHandler);
