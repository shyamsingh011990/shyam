package main
import (
    "log"
    "github.com/douglasmakey/go-fcm"
    )

func main() {
    // init client
    client := fcm.NewClient("AIzaSyBnjZw6i_EE1Y9h7EGpUq1sorB-Wj9IQN0")
token:="eUF5FoE_wZg:APA91bFFu-hdFL6N55gs8DHco0xSEm3ZV5KszElUjCWGBKfQEz4ancByIB09GojtUoELl66sUoAPMBSj0rR7aRizqBwjBrzIxFu_LbfDsCkra_pdIaBrTSM3WZOY_B1YuBM0qKU0YwOv"
    // You can use your HTTPClient 
    //client.SetHTTPClient(client)

    data := map[string]interface{}{
        "message": "hello world",
        "tile": "hello world",
        "details": map[string]string{
            "name": "shyam",
            "user": "shyam",
            "thing": "none",
        },
    }

    // You can use PushMultiple or PushSingle
   // client.PushMultiple([]string{"token 1", "token 2"}, data)
    client.PushSingle(token, data)

    // registrationIds remove and return map of invalid tokens
    badRegistrations := client.CleanRegistrationIds()
    log.Println(badRegistrations) 

    status, err := client.Send()
    if err != nil {
        log.Fatalf("error: %v", err)
    }

    log.Println(status.Results)
}